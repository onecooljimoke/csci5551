//-----------------------------------------------------------------------
// Graph Coloring with equal width partitioning
//-----------------------------------------------------------------------
//  Implementation of coloring algorithm detailed in:
//  A. Gebremedhin and F. Manne, 'Scalable parallel graph coloring algorithms',
//  Concurrency: Pract. Exper., vol. 12, no. 12, pp. 1131-1146, 2000
//  Programming by: Jeff Flower
//-----------------------------------------------------------------------
#include <iostream>
#include <string>
#include <cstring>
#include <omp.h>
#include <time.h>
#include <set>
#include <iomanip>
#include "file-output.h"
#include "utilities.h"
#include "graph.h"

using namespace std;

//------------------------------------------------------------------
// Main Program
//------------------------------------------------------------------
int main(int argc, char *argv[])
{
	int num_vertices;
        int num_threads;
        int *vertices;  // pointer to array of vertex color values
        bool** adj_matrix;  // pointer to array of arrays that represent adj matrix
	char* infile;    // name of file for reading graph data from
        char* outfile;  // name of file for writing summary to
        set<int> conflicts;  // holds vertices with coloring conflicts (neighbors use the same color)
        omp_lock_t conflicts_lock;  // lock for parallel synchronization
        int highest_color;  // holds largest color used
        set<int>::iterator it;
	double runtime;

	if (GetUserInput(argc, argv, num_threads, num_vertices, infile, outfile)==false) return 1;

        //specify number of threads created in parallel region
	omp_set_num_threads(num_threads);

        //Initialize lock, will be used for Step 2
        omp_init_lock(&conflicts_lock);
        
        //initialize matrix 
        InitializeAdjacencies(adj_matrix, num_vertices);
        InitializeColors(vertices, num_vertices);
        //InitializeTestMatrix(adj_matrix);

        //Read graph into matrix
        if (ReadGraph(infile, adj_matrix) == false) {
          cout << "Unable to read graph from " << infile << "\n";
          cout << "Terminating program\n";
          return 1;
        }

        cout << "Coloring begins... now\n";

        // Start clock
        runtime = omp_get_wtime();

        #pragma omp parallel shared(vertices, adj_matrix, conflicts, highest_color)
          {
            //Step 1, Generate a pseudo coloring
            #pragma omp for schedule(static)
            for(int i = 1; i < num_vertices; ++i)
              {
                set<int> color_list;

                //get neighboring colors to vertex i
                BuildColorList(vertices, adj_matrix[i], num_vertices, color_list);

                //find the lowest available color and assign to vertex i
                int lowest_color = FindAvailableColor(color_list);
                vertices[i] = lowest_color;
              }
            
            //Step 2, each block scans vertices for conflicts
            #pragma omp for schedule(static)
            for (int i = 1; i < num_vertices; ++i) {

              bool* adjacencies = adj_matrix[i];
              int color = vertices[i];

              //start iteration at 1 since vertex labels start at 1
              // to avoid double checking an edge, stop iteration at i
              for(int j = 1; j < i; ++j){
                if(adjacencies[j]){
                  if (vertices[j] == color) {
                    // only add the lower of the vertices to conflicts to 
                    // avoid duplicate conflict resolution
                    int conflict_vertex;
                    i < j ? conflict_vertex = i : conflict_vertex = j;

                    //use lock to insure atomicity of set insertion
                    omp_set_lock(&conflicts_lock);
                    conflicts.insert(conflict_vertex);
                    omp_unset_lock(&conflicts_lock);
                  }
                }
              }
            }
          }

          //Step 3, sequentially resolve conflicts
          for(it = conflicts.begin(); it != conflicts.end(); ++it){
            //*it == vertex number
            int vertex = *it;
            set<int> color_list;

            BuildColorList(vertices, adj_matrix[vertex], num_vertices, color_list);
            int lowest_color = FindAvailableColor(color_list);
            vertices[vertex] = lowest_color;            
          }
        
        // finish runtime clocking
        runtime = omp_get_wtime() - runtime;
        
        // find highest color
        highest_color = FindHighestColor(vertices, num_vertices);

        // write results file
        WriteStats(outfile, num_vertices, highest_color, runtime);
        WriteColors(outfile, vertices, num_vertices);
        WriteConflicts(outfile, conflicts);

        CleanUp(adj_matrix, num_vertices, vertices);

        cout << "Coloring ended\n";
        cout << "Runtime: ";
        cout << setiosflags(ios::fixed) << setprecision(6) << runtime << " seconds\n";
        cout << "Colors used: " << highest_color << "\n";
        cout << "Results output to " << outfile << "\n";
	return 0;
}
