//------------------------------------------------------------------
// file-output.cpp
// Implementation of functions defined in FileOutput.h
//------------------------------------------------------------------

#include "file-output.h"
#include <fstream>
#include <iostream>
#include <iomanip>
#include <set>

using namespace std;

void WriteStats(char *filename, int num_vertices, int num_colors, double runtime)
{
  ofstream outfile(filename);
  
  if(outfile.is_open() ){
    outfile << "Number of vertices: " << num_vertices - 1 << "\n";
    outfile << "Number of colors used: " << num_colors << "\n";
    outfile << "Runtime: ";
    outfile << setiosflags(ios::fixed) << setprecision(6) << runtime << " seconds\n";
    outfile.close();
  }
  
  else cout << "Unable to open " << filename << " for writing\n";
}


void WriteColors(char *filename, int* vertices, int num_vertices)
{
  ofstream outfile(filename, fstream::app);
  set<int>::iterator it;

  if(outfile.is_open())
  {
    //write out vertex colors
    outfile << "Vertex Colors:\n";
    for(int i = 1; i < num_vertices; ++i){
      outfile << i << " : " << vertices[i] << "\n";
    }
    
    outfile.close();
  }
  else cout << "Unable to open " << filename << " for writing\n";
}

void WriteConflicts(char *filename,  set<int>& conflicts)
{
  ofstream outfile(filename, fstream::app);
  set<int>::iterator it;

  if(outfile.is_open())
  {    
    // write out conflicts
    outfile << "\nColoring conflicts resolved:\n";
    for(it = conflicts.begin(); it != conflicts.end(); ++it){
      outfile << "Vertex " << *it << "\n";
    }    

    outfile.close();
  }
  else cout << "Unable to open " << filename << " for writing\n";
}
