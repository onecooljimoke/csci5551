#ifndef FILE_OUTPUT
#define FILE_OUTPUT
//------------------------------------------------------------------
// file-output.h
// Function declarations for writing graph coloring results to 
// user defined output file
//------------------------------------------------------------------

#include <set>

using namespace std;

void WriteStats(char *filename, int num_vertices, int num_colors, double runtime);
void WriteColors(char *filename, int* vertices, int num_vertices);
void WriteConflicts(char *filename,  set<int>& conflicts);

//------------------------------------------------------------------
// void WriteStats(char *filename, int num_vertices, int num_colors, double runtime);
// Write # of vertices, edges, colors and runtime to file
// filename: pointer to filename
// adj_list: list of adjacencies by vertex in graph
// num_vertices: number of vertices in graph
// runtime: double, runtime in seconds
//------------------------------------------------------------------

//------------------------------------------------------------------
// void WriteColors(char *filename, int* vertices, int num_vertices)
// Appends to existing file
// filename: pointer to filename
// vertices: pointer to vertex color array
// num_vertices: number of vertices in the graph
//------------------------------------------------------------------

//------------------------------------------------------------------
// void WriteConflicts(char *filename,  set<int>& conflicts)
// Append conflicts resolved to file
// filename: pointer to filename
// conflicts: set of vertices with coloring conflict
//------------------------------------------------------------------

#endif
