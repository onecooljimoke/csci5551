//-----------------------------------------------------------------------
// graph.cpp
//-----------------------------------------------------------------------
// graph coloring function implementations
//-----------------------------------------------------------------------

#include "graph.h"
#include <omp.h>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

using namespace std;

void InitializeColors(int* &vertices, const int& num_vertices)
{
  vertices = new int[num_vertices];

  #pragma omp parallel shared(vertices, num_vertices) 
  {
    #pragma omp for schedule(dynamic)
    for(int i = 0; i < num_vertices; ++i)
      vertices[i] = num_vertices + 1;
  }
  
  return;
}

bool ReadGraph(char* filename, bool**& adj_matrix)
{
  ifstream infile(filename);
  string temp;

  if(infile.is_open()){
    
    while( getline(infile, temp ) ){
      // each line is 2 space separated numbers
      // read the numbers to v1 and v2
      int v1, v2; // vertex numbers
      istringstream ss(temp);
      ss >> v1;
      ss >> v2;
      adj_matrix[v1][v2] = true;
      adj_matrix[v2][v1] = true;
    }

    infile.close();
    return true;
  }

  return false;
}

void InitializeTestList1(int **&a)
{
  a = new int*[10];

  a[0] = new int[5];
  a[1] = new int[4];
  a[2] = new int[4];
  a[3] = new int[2];
  a[4] = new int[5];
  a[5] = new int[5];
  a[6] = new int[3];
  a[7] = new int[3];
  a[8] = new int[3];
  a[9] = new int[6];

  a[0][0] = 4;
  a[0][1] = 1;
  a[0][2] = 4;
  a[0][3] = 7;
  a[0][4] = 8;
  a[1][0] = 3;
  a[1][1] = 0;
  a[1][2] = 5;
  a[1][3] = 9;
  a[2][0] = 3;
  a[2][1] = 3;
  a[2][2] = 4;
  a[2][3] = 5;
  a[3][0] = 1;
  a[3][1] = 2;
  a[4][0] = 4;
  a[4][1] = 0;
  a[4][2] = 2;
  a[4][3] = 5;
  a[4][4] = 9;
  a[5][0] = 4;
  a[5][1] = 1;
  a[5][2] = 2;
  a[5][3] = 4;
  a[5][4] = 6;
  a[6][0] = 2;
  a[6][1] = 5;
  a[6][2] = 9;
  a[7][0] = 2;
  a[7][1] = 0;
  a[7][2] = 9;
  a[8][0] = 2;
  a[8][1] = 0;
  a[8][2] = 9;
  a[9][0] = 5;
  a[9][1] = 1;
  a[9][2] = 4;
  a[9][3] = 6;
  a[9][4] = 7;
  a[9][5] = 8;
  

  return;
}

void InitializeTestList2(int **&a)
{
  a = new int*[10];

  for(int i = 0; i < 10; ++i)
    {
      a[i] = new int[5];
      a[i][0] = 4;
      a[i][1] = ( (i-2) + 10 ) % 10;
      a[i][2] = ( (i-1) + 10 ) % 10;
      a[i][3] = (i+1) % 10;
      a[i][4] = (i+2) % 10;
    }

  return;
}

void InitializeTestMatrix(bool **&a)
{
  a[1][9] = true;
  a[1][10] = true;
  a[1][2] = true;
  a[1][3] = true;
  a[2][10] = true;
  a[2][1] = true;
  a[2][3] = true;
  a[2][4] = true;
  a[3][1] = true;
  a[3][2] = true;
  a[3][4] = true;
  a[3][5] = true;
  a[4][2] = true;
  a[4][3] = true;
  a[4][5] = true;
  a[4][6] = true;
  a[5][3] = true;
  a[5][4] = true;
  a[5][6] = true;
  a[5][7] = true;
  a[6][4] = true;
  a[6][5] = true;
  a[6][7] = true;
  a[6][8] = true;
  a[7][5] = true;
  a[7][6] = true;
  a[7][8] = true;
  a[7][9] = true;
  a[8][6] = true;
  a[8][7] = true;
  a[8][9] = true;
  a[8][10] = true;
  a[9][7] = true;
  a[9][8] = true;
  a[9][10] = true;
  a[9][1] = true;
  a[10][8] = true;
  a[10][9] = true;
  a[10][1] = true;
  a[10][2] = true;
  
  return;
}

void BuildColorList(const int* vertices, const bool* neighbors, int num_vertices, set<int>& color_list)
{
  // load color list
  for(int i = 1; i < num_vertices; ++i)
    {
      // neighbors is list of bool, true if vertices are adjacent
      if (neighbors[i]) {
        color_list.insert( vertices[i] );
      }
      
    }

  return;
}

int FindAvailableColor(set<int>& color_list)
{
  int color = 1;
  set<int>::iterator it;

  for(it = color_list.begin(); it != color_list.end(); ++it){
    if (color == *it) {
      ++color;
    } 
    else {
      return color;
    }
  }

  return color;
}

int FindHighestColor(const int* vertices, int num_vertices)
{
  int global_highest = 0;  // shared variable among threads
  int local_highest;  // will be local to each thread

  #pragma omp parallel shared(vertices, num_vertices, global_highest) private(local_highest)
  {
    // initialize local_highest
    local_highest = 0;

    // find highest color in each thread
    #pragma omp for schedule(static)
    // vertex colors start at index 1
    for(int i = 1; i < num_vertices; ++i){
      if(vertices[i] > local_highest){
        local_highest = vertices[i];
      }

    }

    // find highest among all threads, only allow one thread at a time to check
    #pragma omp critical
    { 
      if(local_highest > global_highest)
        global_highest = local_highest;
    }
    
  }

  return global_highest;
}
