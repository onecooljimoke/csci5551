#ifndef GRAPH
#define GRAPH

//-----------------------------------------------------------------------
// graph.h
//-----------------------------------------------------------------------
// graph coloring function declarations
//-----------------------------------------------------------------------

#include <set>

using namespace std;

void InitializeColors(int* &vertices, const int& num_vertices);
void InitializeTestList1(int **&a);
void InitializeTestList2(int **&a);
void InitializeTestMatrix(bool **&a);
bool ReadGraph(char* filename, bool**& adj_matrix);
void BuildColorList(const int* vertices, const bool* neighbors, int num_vertices, set<int>& color_list);
int FindAvailableColor(set<int>& color_list);
int FindHighestColor(const int* vertices, int num_vertices);

//------------------------------------------------------------------
// void InitializeColors(int* &vertices, const int& num_vertices)
// vertices: int*, will hold the color of each vertex in the graph
// num_vertices: int, number of vertices in the graph
// Assigns initial color to each vertex **in parallel**
// Assign a color value of num_vertices + 1 to each vertex
// since the most colors any graph will use is at most the
// number of vertices
//------------------------------------------------------------------

//------------------------------------------------------------------
// bool ReadGraph(char* filename, bool**& adj_matrix);
// read a list of edges from a file and add adjacencies to the
// adjacency matrix
// return true if successful
//------------------------------------------------------------------


//------------------------------------------------------------------
// void InitializeTestList1(int **&a) 
// build an adjacency list on 10 colors for testing
// a: int**, holds the adjacency list
// first element of each array holds the number of adjacent vertices in the list
// ex: x[0] = [3 1 2 3], x[0][0] = 3 means there are 3 adjacent vertices to vertex 0
//------------------------------------------------------------------

//------------------------------------------------------------------
// void InitializeTestList2(int **&a)
// build an adjacency list on 10 colors for testing
// a: int**, holds the adjacency list
// first element of each array holds the number of adjacent vertices in the list
// ex: x[0] = [3 1 2 3], x[0][0] = 3 means there are 3 adjacent vertices to vertex 0
//------------------------------------------------------------------

//------------------------------------------------------------------
// void InitializeTestMatrix(int **&a)
// build an adjacency matrix on 10 colors for testing
// a: int**, holds the adjacency list
// first element of each array holds the number of adjacent vertices in the list
// ex: x[0] = [3 1 2 3], x[0][0] = 3 means there are 3 adjacent vertices to vertex 0
//------------------------------------------------------------------

//------------------------------------------------------------------
//void BuildColorList(const int* vertices, const bool* neighbors, int num_vertices, set<int>& color_list);
// add neighboring colors to color_list
// vertices: pointer to array of vertex colors
// neighbors: pointer to an array of adjacent vertices, the first
//            value will be the number of adjacent vertices
// num_vertices: number of vertices in graph
// color_list: list of colors of adjacent vertices
// Upon completion color_list is filled with unique vertex colors 
//------------------------------------------------------------------

//------------------------------------------------------------------
// int FindAvailableColor(set<int>& color_list)
// Return the lowest available color in graph 
// color_list: std::set, members already stored in sorted order
//------------------------------------------------------------------

//------------------------------------------------------------------
// int FindHighestColor(const int* vertices, int num_vertices)
// Return the highest color used to color the graph 
// vertices: pointer to array of vertex colors
// num_vertices: number of vertices in the graph
//------------------------------------------------------------------

#endif
