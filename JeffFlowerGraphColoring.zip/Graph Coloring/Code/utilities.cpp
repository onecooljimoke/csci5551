//------------------------------------------------------------------
// utilities.cpp
// Function implementations of utilities.h
//------------------------------------------------------------------

#include "utilities.h"
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <omp.h>

using namespace std;

bool GetUserInput(int argc, char *argv[], int& num_threads, int& num_vertices, char*& infile, char*& outfile)
{
  bool isOK = true;

  if(argc < 5) 
    {
      cout << "Expected 4 Arguments\n";
      cout << "1) Number of threads\n";
      cout << "2) Number of vertices\n";
      cout << "3) Filename for graph input\n";
      cout << "4) Filename for graph output\n";
      isOK = false;
    }
  else 
    {
      //get number of threads
      num_threads = atoi(argv[1]);
      if (num_threads <=0) 
        {
          cout << "Number of threads must be larger than 0\n";
          isOK = false;
        }

      //get number of vertices
      // add one to the argument since the vertex numbers start at 1
      num_vertices = atoi(argv[2]) + 1;
      if (num_vertices <=0) 
        {
          cout << "Number of threads must be larger than 0\n";
          isOK = false;
        }

      //get filename to read from
      infile = new char[100];
      strncpy(infile, argv[3], 100);

      //get filename to write to
      outfile = new char[100];
      strncpy(outfile, argv[4], 100);

    }
  return isOK;
}

void CleanUp(bool **adj_matrix, int num_vertices, int* vertices )
{
  delete [] adj_matrix[0];
  delete [] adj_matrix;
  delete[] vertices;
}

void InitializeAdjacencies(bool** &adj_matrix, int num_vertices)
{
  adj_matrix = new bool*[num_vertices]; 
  adj_matrix[0] = new bool[num_vertices * num_vertices];
  for (int i = 1; i < num_vertices; i++)	
    adj_matrix[i] = adj_matrix[i-1] + num_vertices;

  #pragma omp parallel for schedule(static) 
    for (int i = 0; i < num_vertices; i++)
      {
        for (int j = 0; j < num_vertices; j++)
          {	
            adj_matrix[i][j] = false;
          }
      }
}

void PrintAdjacencyList(int **adj_list, int num_vertices)
{
  cout << "Adjacency List:\n";

  for (int i = 0; i < 10; ++i)
    {
      int end = adj_list[i][0];  //a[i][0] holds the length of rest of the array
        
      cout << "Vertex: " << i << ":\t" ;
      //print each member and a comma except the last member
      for (int j = 1 ; j < end; ++j)
        {
          cout << adj_list[i][j] << ", ";
        }
      //print the last member
      cout << adj_list[i][end] << "\n";
    }
}
