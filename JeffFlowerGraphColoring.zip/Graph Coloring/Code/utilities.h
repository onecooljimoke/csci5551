#ifndef UTILITIES
#define UTILITIES

//------------------------------------------------------------------
// utilities.h
// Function declarations for miscellaneous graph coloring function
//------------------------------------------------------------------

bool GetUserInput(int argc, char *argv[], int& num_threads, int& num_vertices, char*& infile, char*& outfile);
void CleanUp(bool **adj_matrix, int num_vertices, int* vertices );
void InitializeAdjacencies(bool** &adj_matrix, int num_vertices);
void PrintAdjacencyList(int **adj_list, int num_vertices);

//------------------------------------------------------------------
// bool GetUserInput(int argc, char *argv[], int& num_threads, int& num_vertices, char*& infile, char*& outfile);
// take command line argument and assign appropriately
// infile: filename to read graph data from
// outfile: filename to write summary information to 
// return false if command line arguments missing
// note that num_vertices is increased by one to account for vertex
// labelling starting at 1
//------------------------------------------------------------------

//------------------------------------------------------------------
// void CleanUp(bool **adj_matrix, int num_vertices, int* vertices );
// Delete pointers
//------------------------------------------------------------------

//-----------------------------------------------------------------------
// void InitializeAdjacencies(bool** &adj_matrix, int num_vertices)
// Initialize the vertex adjacencies of adj_matrix
// adj_matrix: int**, will hold the adjacency matrix for the graph
// num_vertices: int, number of vertices in the graph 
// 
//-----------------------------------------------------------------------

//------------------------------------------------------------------
// void PrintAdjacencyList(int **adj_list, int num_vertices) 
//Print each vertex and it's list of adjacencies
// adj_list: int**
// num_vertices: int
//------------------------------------------------------------------

#endif
