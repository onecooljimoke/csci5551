Parallel Graph Coloring
=======================

To test the code:
1) Upload the 'Code', 'GraphFiles' and 'Results' folders to dozer (dozer.ucdenver.pvt)
2) On dozer, change your working directory to 'Code'
3) To compile the code, enter the command: 'make all'
   This will produce an executable named 'color'
4) To run the program: ./color <# of processors> <# of vertices> <path to graph file> <output path for results>
   Example: ./color 12 1000 ../GraphFiles/1000-249826.txt ../Results/results.txt
   Runs the program with 12 processes, 1000 vertices using the graph file 1000-249826.txt and writes
   the results to ../Results/results.txt
5) To test any of the graph files with different numbers of processors line in my analysis:
	'make color1000' OR 'make color4039' OR 'make color 36692'
	This will the test the associated graph file with 1, 2, 4, 8 and 12 processors and output the results
	to the Results folder.
6) If you want, get rid of those annoying '.o' files with 'make clean'	